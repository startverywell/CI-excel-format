$(document).ready(function() {
    $('#container-table').DataTable();
});
