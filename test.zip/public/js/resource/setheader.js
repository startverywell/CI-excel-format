$(document).ready(function() {
    $('#header-table').DataTable();
});